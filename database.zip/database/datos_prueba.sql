-- Usuarios de ejemplo (uno por rol)
INSERT INTO USUARIO(nombre_usuario, contrasenia, rol) VALUES('asistente01','1234','ASISTENTE');
INSERT INTO USUARIO(nombre_usuario, contrasenia, rol) VALUES('guarda01','1234','GUARDA');
INSERT INTO USUARIO(nombre_usuario, contrasenia, rol) VALUES('chofer01','1234','CHOFER');

COMMIT;
